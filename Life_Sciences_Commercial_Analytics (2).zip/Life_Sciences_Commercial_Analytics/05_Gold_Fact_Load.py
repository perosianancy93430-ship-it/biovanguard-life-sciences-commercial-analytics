# Databricks notebook source
# DBTITLE 1,Gold Fact Load — Title
# MAGIC %md
# MAGIC # Gold Fact Load
# MAGIC
# MAGIC Loads the daily commercial sales fact incrementally: only new/updated rows from silver are staged, then upserted into gold without duplicates.
# MAGIC
# MAGIC **Input:** `biovanguard.silver.slv_daily_prescriptions` + gold dimensions  
# MAGIC **Output:** `biovanguard.gold.fact_daily_commercial_sales`

# COMMAND ----------

# DBTITLE 1,Setup header
# MAGIC %md
# MAGIC ## 1. Setup & Imports

# COMMAND ----------

from pyspark.sql import functions as F
from delta.tables import DeltaTable

# COMMAND ----------

# DBTITLE 1,Fact build header
# MAGIC %md
# MAGIC ## 2. Build Fact Batch
# MAGIC
# MAGIC Joins silver prescriptions to all 5 gold dimensions. The rep join is point-in-time on the transaction date (SCD2). Computes Gross = Units × WAC, Rebate = Gross × Rebate %, Net = Gross − Rebate. When a watermark is given, only rows at or after that date are joined.

# COMMAND ----------

# DBTITLE 1,Build fact from combined source
FACT_TABLE = "biovanguard.gold.fact_daily_commercial_sales"
STAGING_TABLE = "biovanguard.silver.stg_fact_daily_commercial_sales"
CONTROL_TABLE = "biovanguard.silver.control_table"

def build_fact(watermark=None):
    """Maps the combined prescription source to dimension keys, raw
    measures, and the documented revenue measures (Gross = Units x
    WAC, Rebate = Gross x Rebate_Pct, Net = Gross - Rebate). The rep
    join uses the assignment version effective on the transaction date
    (historical territory truth). When a watermark date is supplied,
    only source rows at or after that date are joined to dimensions
    (true incremental filtering before the joins, not after)."""

    sales = spark.table(
        "biovanguard.silver.slv_daily_prescriptions"
    ).alias("s")

    # Apply the watermark to the source BEFORE dimension joins so only
    # new/updated rows are processed (true incremental load).
    if watermark is not None:
        sales = sales.filter(F.col("s.trx_date") >= F.lit(watermark))

    date_dim = spark.table(
        "biovanguard.gold.dim_date"
    ).alias("d")

    hcp_dim = spark.table(
        "biovanguard.gold.dim_hcp"
    ).alias("h")

    hco_dim = spark.table(
        "biovanguard.gold.dim_hco"
    ).alias("o")

    product_dim = spark.table(
        "biovanguard.gold.dim_product"
    ).alias("p")

    rep_dim = spark.table(
        "biovanguard.gold.dim_sales_rep"
    ).alias("r")

    joined = (
        sales
        .join(date_dim, F.col("s.trx_date") == F.col("d.Calendar_Date"), "inner")
        .join(hcp_dim, F.col("s.npi_number") == F.col("h.NPI_Number"), "inner")
        .join(hco_dim, F.col("s.facility_id") == F.col("o.Facility_ID"), "inner")
        .join(product_dim, F.col("s.ndc_code") == F.col("p.NDC_Code"), "inner")
        .join(
            rep_dim,
            (
                (F.col("s.rep_emp_id") == F.col("r.Rep_Employee_ID"))
                & (F.col("s.trx_date") >= F.col("r.Effective_Start_Date"))
                & (F.col("s.trx_date") <= F.col("r.Effective_End_Date"))
            ),
            "inner",
        )
    )

    fact = joined.select(
        F.col("d.Date_Key").alias("Date_Key"),
        F.col("h.HCP_Key").alias("HCP_Key"),
        F.col("o.HCO_Key").alias("HCO_Key"),
        F.col("p.Product_Key").alias("Product_Key"),
        F.col("r.Rep_Key").alias("Rep_Key"),
        F.col("s.channel").alias("Channel_Type"),
        F.col("s.trx_count").alias("TRx_Count"),
        F.col("s.nrx_count").alias("NRx_Count"),
        F.col("s.units_dispensed").alias("Units_Dispensed"),
        F.col("p.WAC_Price").alias("WAC_Price"),
        F.col("s.rebate_pct").alias("Rebate_Pct"),
    )

    # Documented revenue measures: Gross = Units x WAC, Rebate = Gross
    # x Rebate_Pct, Net = Gross - Rebate. WAC and rebate % are joined in
    # to compute them but never stored themselves.
    fact = (
        fact
        .withColumn(
            "Gross_Sales_Amount",
            (F.col("Units_Dispensed") * F.col("WAC_Price")).cast("decimal(18,2)"),
        )
        .withColumn(
            "Rebate_Amount",
            (F.col("Gross_Sales_Amount") * F.col("Rebate_Pct")).cast("decimal(18,2)"),
        )
        .withColumn(
            "Net_Sales_Amount",
            (F.col("Gross_Sales_Amount") - F.col("Rebate_Amount")).cast("decimal(18,2)"),
        )
        .withColumn("Loaded_At", F.current_timestamp())
    )

    return fact.select(
        "Date_Key", "HCP_Key", "HCO_Key",
        "Product_Key", "Rep_Key", "Channel_Type",
        "TRx_Count", "NRx_Count", "Units_Dispensed",
        "Gross_Sales_Amount", "Rebate_Amount", "Net_Sales_Amount",
        "Loaded_At",
    )

# COMMAND ----------

# DBTITLE 1,Source to staging header
# MAGIC %md
# MAGIC ## 3. Source → Staging: Watermark Filter
# MAGIC
# MAGIC Reads the control-table watermark, filters the source to only new/updated rows, and refreshes the staging table with that batch. No control row yet means full load. `>=` keeps same-day late arrivals.

# COMMAND ----------

# DBTITLE 1,Source to staging refresh
# Read the high-water mark from the control table. No row yet -> full load.
_wm_rows = spark.sql(f"""
    SELECT MAX_MODIFIED_DATE
    FROM {CONTROL_TABLE}
    WHERE TABLE_NAME = 'SLV_DAILY_PRESCRIPTIONS'
""").collect()
WATERMARK = _wm_rows[0]["MAX_MODIFIED_DATE"] if _wm_rows else None

# Pass the watermark into build_fact() so the silver source is filtered
# BEFORE the dimension joins (true incremental load). When watermark is
# None (first run / no control row), build_fact() loads the full source.
incremental_fact = build_fact(watermark=WATERMARK)

print("Control-table watermark (SLV_DAILY_PRESCRIPTIONS):", WATERMARK)
print("New/updated rows at/after watermark:", incremental_fact.count())

# One-time reshape: the staging table carries the same columns as the
# fact, including the computed revenue measures — add them if the table
# was created by an older (slim) version of this notebook.
_stage_fields = {f.name for f in spark.table(STAGING_TABLE).schema.fields}
if not {"Gross_Sales_Amount", "Rebate_Amount", "Net_Sales_Amount"} <= _stage_fields:
    spark.sql(f"""
        ALTER TABLE {STAGING_TABLE} ADD COLUMN (
            Gross_Sales_Amount DECIMAL(18,2),
            Rebate_Amount DECIMAL(18,2),
            Net_Sales_Amount DECIMAL(18,2)
        )
    """)

# Refresh the staging table with ONLY the new/updated batch (columns
# aligned to the table order so the overwrite resolves cleanly).
(
    incremental_fact
    .select(*[f.name for f in spark.table(STAGING_TABLE).schema.fields])
    .write
    .format("delta")
    .mode("overwrite")
    .saveAsTable(STAGING_TABLE)
)

print("Staging rows after refresh (current batch only):", spark.table(STAGING_TABLE).count())

# COMMAND ----------

# DBTITLE 1,Staging to target header
# MAGIC %md
# MAGIC ## 4. Staging → Gold Fact: Upsert
# MAGIC
# MAGIC Creates the fact table if missing, rejects duplicate grains, then upserts the staging batch into the gold fact matched on the 6-column grain. Advances the control-table watermark after success.

# COMMAND ----------

# DBTITLE 1,Stage to target upsert + watermark advance
# The gold fact keeps the dimension keys, raw measures, and the
# computed revenue measures (Gross / Rebate / Net) — no business key.
FACT_COLUMNS = [
    "Date_Key", "HCP_Key", "HCO_Key",
    "Product_Key", "Rep_Key", "Channel_Type",
    "TRx_Count", "NRx_Count", "Units_Dispensed",
    "Gross_Sales_Amount", "Rebate_Amount", "Net_Sales_Amount",
    "Loaded_At",
]

GRAIN_COLUMNS = [
    "Date_Key", "HCP_Key", "HCO_Key",
    "Product_Key", "Rep_Key", "Channel_Type",
]

# Ensure the gold fact table exists (schema-only create on first run)
(
    spark.table(STAGING_TABLE)
    .select(*FACT_COLUMNS)
    .limit(0)
    .write
    .format("delta")
    .mode("ignore")
    .saveAsTable(FACT_TABLE)
)

# One-time reshape: align the fact with the documented schema — add
# the revenue measures if the table was created by an older (slim)
# version of this notebook (idempotent no-op once aligned).
_fact_fields = {f.name for f in spark.table(FACT_TABLE).schema.fields}
if not {"Gross_Sales_Amount", "Rebate_Amount", "Net_Sales_Amount"} <= _fact_fields:
    spark.sql(f"""
        ALTER TABLE {FACT_TABLE} ADD COLUMN (
            Gross_Sales_Amount DECIMAL(18,2),
            Rebate_Amount DECIMAL(18,2),
            Net_Sales_Amount DECIMAL(18,2)
        )
    """)

print("Fact columns:", spark.table(FACT_TABLE).columns)

stage_batch = spark.table(STAGING_TABLE)

# Guard: reject a staging batch with duplicate fact grains.
duplicate_grains = (
    stage_batch
    .groupBy(*GRAIN_COLUMNS)
    .count()
    .filter(F.col("count") > 1)
)
if duplicate_grains.limit(1).count() > 0:
    raise ValueError("Duplicate fact grains found in staging table.")

# Upsert new/updated staging records into the gold fact, matched on the
# fact grain (date + HCP + HCO + product + rep version + channel).
fact_target = DeltaTable.forName(spark, FACT_TABLE)

(
    fact_target.alias("t")
    .merge(
        stage_batch.alias("s"),
        """t.Date_Key = s.Date_Key
           AND t.HCP_Key = s.HCP_Key
           AND t.HCO_Key = s.HCO_Key
           AND t.Product_Key = s.Product_Key
           AND t.Rep_Key = s.Rep_Key
           AND t.Channel_Type = s.Channel_Type""",
    )
    .whenMatchedUpdateAll()
    .whenNotMatchedInsertAll()
    .execute()
)

# Advance the control-table watermark to the newest transaction date
# now covered by the fact (silver is fully loaded upstream).
_new_wm = (
    spark.table("biovanguard.silver.slv_daily_prescriptions")
    .agg(F.max("trx_date").alias("MAX_MODIFIED_DATE"))
    .collect()[0]["MAX_MODIFIED_DATE"]
)
spark.sql(f"""
    MERGE INTO {CONTROL_TABLE} t
    USING (
        SELECT 'SLV_DAILY_PRESCRIPTIONS' AS TABLE_NAME,
               MIN(trx_date) AS MAX_CREATED_DATE,
               MAX(trx_date) AS MAX_MODIFIED_DATE,
               current_timestamp() AS LAST_RUN_DATE
        FROM biovanguard.silver.slv_daily_prescriptions
    ) s
    ON t.TABLE_NAME = s.TABLE_NAME
    WHEN MATCHED THEN UPDATE SET
        t.MAX_MODIFIED_DATE = s.MAX_MODIFIED_DATE,
        t.LAST_RUN_DATE = s.LAST_RUN_DATE
    WHEN NOT MATCHED THEN INSERT *
""")
print("Gold fact rows after upsert:", spark.table(FACT_TABLE).count())
print("Control-table watermark advanced to:", _new_wm)

# COMMAND ----------

# DBTITLE 1,Idempotency header
# MAGIC %md
# MAGIC ## 5. Idempotency Check
# MAGIC
# MAGIC Re-runs the upsert. Row count must stay the same with no duplicate grains.

# COMMAND ----------

# DBTITLE 1,Idempotency re-run
# Idempotency check: re-running the staging -> fact upsert must not
# change the row count or duplicate the fact grain.
fact_target = DeltaTable.forName(spark, FACT_TABLE)

(
    fact_target.alias("t")
    .merge(
        spark.table(STAGING_TABLE).alias("s"),
        """t.Date_Key = s.Date_Key
           AND t.HCP_Key = s.HCP_Key
           AND t.HCO_Key = s.HCO_Key
           AND t.Product_Key = s.Product_Key
           AND t.Rep_Key = s.Rep_Key
           AND t.Channel_Type = s.Channel_Type""",
    )
    .whenMatchedUpdateAll()
    .whenNotMatchedInsertAll()
    .execute()
)

_fact_rows = spark.table(FACT_TABLE).count()
_dupe_grains = (
    spark.table(FACT_TABLE)
    .groupBy(*GRAIN_COLUMNS)
    .count()
    .filter(F.col("count") > 1)
    .limit(1)
    .count()
)
print("Fact rows after idempotency re-run:", _fact_rows)
print("Duplicate fact grains:", _dupe_grains)

# COMMAND ----------

# DBTITLE 1,Reconciliation header
# MAGIC %md
# MAGIC ## 6. Reconciliation
# MAGIC
# MAGIC Confirms gold fact row count matches silver, and every staging grain is present in the fact.

# COMMAND ----------

# DBTITLE 1,Source stage target reconciliation
src_rows = spark.table("biovanguard.silver.slv_daily_prescriptions").count()
stg_rows = spark.table(STAGING_TABLE).count()
tgt_rows = spark.table(FACT_TABLE).count()

missing_grains = (
    spark.table(STAGING_TABLE)
    .select(*GRAIN_COLUMNS)
    .exceptAll(
        spark.table(FACT_TABLE).select(*GRAIN_COLUMNS)
    )
    .limit(1)
    .count()
)

print(f"Source rows (slv_daily_prescriptions): {src_rows}")
print(f"Staging rows (current new/updated batch): {stg_rows}")
print(f"Gold fact rows (accumulated): {tgt_rows}")
print("Staging grains missing from fact:", missing_grains)

# COMMAND ----------

# DBTITLE 1,Gold fact validation header
# MAGIC %md
# MAGIC ## 7. Fact Validation
# MAGIC
# MAGIC Spot checks: silver vs fact counts and totals, Net = Gross − Rebate rule, and orphan keys.

# COMMAND ----------

# DBTITLE 1,Simple fact checks
# Simple fact checks: counts/totals vs silver, revenue rule, orphan keys.
checks = spark.sql(f"""
    SELECT
        (SELECT COUNT(*) FROM biovanguard.silver.slv_daily_prescriptions) AS silver_rows,
        (SELECT COUNT(*) FROM {FACT_TABLE}) AS fact_rows,
        (SELECT SUM(trx_count) FROM biovanguard.silver.slv_daily_prescriptions) AS silver_trx,
        (SELECT SUM(TRx_Count) FROM {FACT_TABLE}) AS fact_trx,
        (SELECT SUM(units_dispensed) FROM biovanguard.silver.slv_daily_prescriptions) AS silver_units,
        (SELECT SUM(Units_Dispensed) FROM {FACT_TABLE}) AS fact_units,
        (SELECT COUNT(*) FROM {FACT_TABLE}
         WHERE ABS(Net_Sales_Amount - (Gross_Sales_Amount - Rebate_Amount)) > 0.01) AS bad_net_rows,
        (SELECT COUNT(*) FROM {FACT_TABLE} f
         LEFT JOIN biovanguard.gold.dim_date d ON f.Date_Key = d.Date_Key
         LEFT JOIN biovanguard.gold.dim_hcp h ON f.HCP_Key = h.HCP_Key
         LEFT JOIN biovanguard.gold.dim_hco o ON f.HCO_Key = o.HCO_Key
         LEFT JOIN biovanguard.gold.dim_product p ON f.Product_Key = p.Product_Key
         LEFT JOIN biovanguard.gold.dim_sales_rep r ON f.Rep_Key = r.Rep_Key
         WHERE d.Date_Key IS NULL OR h.HCP_Key IS NULL OR o.HCO_Key IS NULL
            OR p.Product_Key IS NULL OR r.Rep_Key IS NULL) AS orphan_keys
""").collect()[0]

print(f"Rows:  silver={checks['silver_rows']}, fact={checks['fact_rows']}")
print(f"TRx:   silver={checks['silver_trx']}, fact={checks['fact_trx']}")
print(f"Units: silver={checks['silver_units']}, fact={checks['fact_units']}")
print("Net = Gross - Rebate violations:", checks["bad_net_rows"])
print("Orphan fact keys:", checks["orphan_keys"])

ok = (checks["silver_rows"] == checks["fact_rows"]
      and checks["silver_trx"] == checks["fact_trx"]
      and checks["silver_units"] == checks["fact_units"]
      and checks["bad_net_rows"] == 0 and checks["orphan_keys"] == 0)
print("Result:", "ALL OK" if ok else "CHECK FAILED")

# COMMAND ----------

# DBTITLE 1,Preview header
# MAGIC %md
# MAGIC ## 8. Fact Table Preview

# COMMAND ----------

# DBTITLE 1,Preview fact table
display(
    spark.table(FACT_TABLE)
    .orderBy("Date_Key", "Rep_Key")
)