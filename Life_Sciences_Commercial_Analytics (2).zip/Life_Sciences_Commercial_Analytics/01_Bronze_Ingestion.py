# Databricks notebook source
# DBTITLE 1,Bronze Ingestion — Title
# MAGIC %md
# MAGIC # BioVanguard Therapeutics — Bronze Ingestion (Step 1)
# MAGIC
# MAGIC Ingests the raw CSV sources from the landing volume into Delta tables in `biovanguard.bronze`, combining initial + delta batches for sales reps and prescriptions.
# MAGIC
# MAGIC **Inputs:** `/Volumes/biovanguard/bronze/landing/*.csv`  
# MAGIC **Outputs:** `biovanguard.bronze.src_calendar`, `src_hcp`, `src_hco`, `src_product`, `src_sales_rep`, `src_daily_prescriptions`

# COMMAND ----------

# DBTITLE 1,Setup header
# MAGIC %md
# MAGIC ## 1. Setup & Source Path
# MAGIC
# MAGIC Imports and landing-volume path used by all ingestion steps.

# COMMAND ----------

# DBTITLE 1,Imports and source path
from pyspark.sql import functions as F

SOURCE_PATH = "/Volumes/biovanguard/bronze/landing/"

print("BioVanguard Bronze - source path:", SOURCE_PATH)

# COMMAND ----------

# DBTITLE 1,Simple sources header
# MAGIC %md
# MAGIC ## 2. Simple Source File Mapping
# MAGIC
# MAGIC Maps single-file sources (calendar, HCP, HCO, product) to their bronze table names.

# COMMAND ----------

# DBTITLE 1,Simple source file mapping
simple_sources = {
    "src_calendar": "src_calendar.csv",
    "src_hcp": "src_hcp.csv",
    "src_hco": "src_hco.csv",
    "src_product": "src_product.csv",
}

# COMMAND ----------

# DBTITLE 1,Simple sources header
# MAGIC %md
# MAGIC ## 3. Landing CSVs → Bronze Tables: `src_calendar`, `src_hcp`, `src_hco`, `src_product`
# MAGIC
# MAGIC Loads each single-file CSV into its bronze Delta table (overwrite mode, all columns as strings).

# COMMAND ----------

# DBTITLE 1,Ingest simple sources to bronze
for table_name, file_name in simple_sources.items():

    file_path = SOURCE_PATH + file_name

    df = (
        spark.read
        .format("csv")
        .option("header", "true")
        .option("inferSchema", "false")
        .load(file_path)
    )

    target_table = f"biovanguard.bronze.{table_name}"

    (
        df.write
        .format("delta")
        .mode("overwrite")
        .saveAsTable(target_table)
    )

    print(
        f"Loaded {target_table}: "
        f"{df.count()} rows"
    )

# COMMAND ----------

# DBTITLE 1,Sales rep ingestion header
# MAGIC %md
# MAGIC ## 4. Landing CSVs (Initial + Delta) → Bronze `src_sales_rep`
# MAGIC
# MAGIC Unions the initial and delta CSV batches with a `source_batch` marker — every assignment version is preserved for SCD2.

# COMMAND ----------

# DBTITLE 1,Build combined src_sales_rep (initial + delta)
rep_columns = [
    "rep_emp_id",
    "rep_name",
    "territory_code",
    "region",
    "role",
    "effective_date",
]

def read_rep_csv(file_name, source_batch):
    return (
        spark.read
        .format("csv")
        .option("header", "true")
        .option("inferSchema", "false")
        .load(SOURCE_PATH + file_name)
        .select(*rep_columns)
        .withColumn("source_batch", F.lit(source_batch))
    )

rep_initial = read_rep_csv("src_sales_rep.csv", "initial")
rep_delta = read_rep_csv("src_sales_rep_delta.csv", "delta")

rep_all = rep_initial.unionByName(rep_delta)

(
    rep_all.write
    .format("delta")
    .mode("overwrite")
    .saveAsTable("biovanguard.bronze.src_sales_rep")
)

print(
    "Loaded biovanguard.bronze.src_sales_rep: "
    f"{rep_all.count()} rows "
    f"(initial {rep_initial.count()} + delta {rep_delta.count()})"
)

# COMMAND ----------

# DBTITLE 1,Prescriptions ingestion header
# MAGIC %md
# MAGIC ## 5. Landing CSVs (May-01 + May-16) → Bronze `src_daily_prescriptions`
# MAGIC
# MAGIC Unions the May-01 and May-16 prescription batches with a `source_batch` marker into `src_daily_prescriptions`.

# COMMAND ----------

# DBTITLE 1,Build combined src_daily_prescriptions
def read_prescriptions_csv(file_name, source_batch):
    return (
        spark.read
        .format("csv")
        .option("header", "true")
        .option("inferSchema", "false")
        .load(SOURCE_PATH + file_name)
        .withColumn("source_batch", F.lit(source_batch))
    )

pres_may01 = read_prescriptions_csv(
    "src_daily_prescriptions_may01.csv", "may01"
)
pres_may16 = read_prescriptions_csv(
    "src_daily_prescriptions_may16.csv", "may16"
)

prescriptions = pres_may01.unionByName(pres_may16)

(
    prescriptions.write
    .format("delta")
    .mode("overwrite")
    .saveAsTable("biovanguard.bronze.src_daily_prescriptions")
)

print(
    "Loaded biovanguard.bronze.src_daily_prescriptions: "
    f"{prescriptions.count()} rows "
    f"(may01 {pres_may01.count()} + may16 {pres_may16.count()})"
)

# COMMAND ----------

# DBTITLE 1,Duplicate check header
# MAGIC %md
# MAGIC ## 6. Bronze `src_daily_prescriptions` — Source Duplicate Check & Preview
# MAGIC
# MAGIC Checks for duplicate records across all business columns and previews the combined prescriptions table.

# COMMAND ----------

# DBTITLE 1,Source duplicate check and preview
dup_check_columns = [
    "trx_date", "npi_number", "facility_id", "ndc_code",
    "rep_emp_id", "channel", "trx_count", "nrx_count",
    "units_dispensed", "rebate_pct",
]

duplicate_rows = (
    spark.table("biovanguard.bronze.src_daily_prescriptions")
    .groupBy(dup_check_columns)
    .count()
    .filter(F.col("count") > 1)
)

print("Duplicate source records:", duplicate_rows.count())

display(
    spark.table("biovanguard.bronze.src_daily_prescriptions")
)

# COMMAND ----------

# DBTITLE 1,Row counts header
# MAGIC %md
# MAGIC ## 7. Bronze Layer Row Count Summary (all `src_*` target tables)
# MAGIC
# MAGIC Row counts for every bronze table after ingestion.

# COMMAND ----------

# DBTITLE 1,Bronze row count summary
bronze_tables = [
    "src_calendar",
    "src_hcp",
    "src_hco",
    "src_product",
    "src_sales_rep",
    "src_daily_prescriptions",
]

for table_name in bronze_tables:

    full_table_name = f"biovanguard.bronze.{table_name}"

    row_count = spark.table(full_table_name).count()

    print(f"{full_table_name}: {row_count} rows")