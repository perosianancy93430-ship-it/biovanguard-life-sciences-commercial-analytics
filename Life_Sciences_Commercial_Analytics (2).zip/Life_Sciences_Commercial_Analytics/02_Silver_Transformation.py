# Databricks notebook source
# DBTITLE 1,Silver Transformation — Title
# MAGIC %md
# MAGIC # BioVanguard Therapeutics — Silver Transformation Layer
# MAGIC
# MAGIC Cleanses and standardizes the six bronze sources (`biovanguard.bronze.src_*`) into conformed silver tables (`biovanguard.silver.slv_*`): trimming/casting, null and range filtering, and preserving **all** sales-rep assignment versions for SCD2 downstream.
# MAGIC
# MAGIC **Inputs:** `biovanguard.bronze.*`  
# MAGIC **Outputs:** `biovanguard.silver.slv_calendar`, `slv_hcp`, `slv_hco`, `slv_product`, `slv_sales_rep`, `slv_daily_prescriptions`  
# MAGIC **Column mapping reference:** `BIOVANGUARD_FACT_MAPPING.xlsx` (workspace)

# COMMAND ----------

# DBTITLE 1,Setup & Imports
# MAGIC %md
# MAGIC ## 1. Setup & Imports
# MAGIC
# MAGIC Imports the Spark SQL functions used across all cleansing steps.

# COMMAND ----------

from pyspark.sql import functions as F

# COMMAND ----------

# DBTITLE 1,Clean Calendar header
# MAGIC %md
# MAGIC ## 2. Bronze `src_calendar` → Silver `slv_calendar` — Clean Calendar Data
# MAGIC
# MAGIC Casts dates and numeric parts, trims labels, and drops rows without a valid `calendar_date`. Note: the source carries no holiday attribute, so gold `Dim_Date.Is_Holiday` defaults to `'N'`.

# COMMAND ----------

# DBTITLE 1,Clean calendar
# Source calendar carries no holiday attribute; the gold Dim_Date
# defaults Is_Holiday to 'N' (documented limitation).
calendar_df = (
    spark.table("biovanguard.bronze.src_calendar")
    .select(
        F.to_date("calendar_date", "yyyy-MM-dd")
            .alias("calendar_date"),
        F.col("day_of_week").cast("int").alias("day_of_week"),
        F.trim("day_name").alias("day_name"),
        F.col("month_number").cast("int").alias("month_number"),
        F.trim("month_name").alias("month_name"),
        F.trim("quarter").alias("quarter"),
        F.col("year").cast("int").alias("year"),
        F.upper(F.trim("is_weekend")).alias("is_weekend"),
    )
    .filter(F.col("calendar_date").isNotNull())
)

calendar_df.write.format("delta").mode("overwrite").saveAsTable(
    "biovanguard.silver.slv_calendar"
)

print("slv_calendar:", calendar_df.count(), "rows")

# COMMAND ----------

# DBTITLE 1,Clean HCP/HCO header
# MAGIC %md
# MAGIC ## 3. Bronze `src_hcp`, `src_hco` → Silver `slv_hcp`, `slv_hco` — Clean HCP & HCO Master Data
# MAGIC
# MAGIC Trims identifiers and names, upper-cases state, and keeps only rows with a non-empty `npi_number` / `facility_id`.

# COMMAND ----------

# DBTITLE 1,Clean HCP and HCO
hcp_df = (
    spark.table("biovanguard.bronze.src_hcp")
    .select(
        F.trim("npi_number").alias("npi_number"),
        F.trim("first_name").alias("first_name"),
        F.trim("last_name").alias("last_name"),
        F.trim("specialty").alias("specialty"),
        F.trim("state_license_number")
            .alias("state_license_number"),
    )
    .filter(
        F.col("npi_number").isNotNull()
        & (F.col("npi_number") != "")
    )
)

hcp_df.write.format("delta").mode("overwrite").saveAsTable(
    "biovanguard.silver.slv_hcp"
)

hco_df = (
    spark.table("biovanguard.bronze.src_hco")
    .select(
        F.trim("facility_id").alias("facility_id"),
        F.trim("facility_name").alias("facility_name"),
        F.trim("facility_type").alias("facility_type"),
        F.trim("city").alias("city"),
        F.upper(F.trim("state")).alias("state"),
        F.trim("zip_code").alias("zip_code"),
    )
    .filter(
        F.col("facility_id").isNotNull()
        & (F.col("facility_id") != "")
    )
)

hco_df.write.format("delta").mode("overwrite").saveAsTable(
    "biovanguard.silver.slv_hco"
)

print("slv_hcp:", hcp_df.count(), "rows")
print("slv_hco:", hco_df.count(), "rows")

# COMMAND ----------

# DBTITLE 1,Clean Product header
# MAGIC %md
# MAGIC ## 4. Bronze `src_product` → Silver `slv_product` — Clean Product Master Data
# MAGIC
# MAGIC Trims text attributes, casts `wac_price` to `decimal(10,2)`, and requires a non-empty `ndc_code`.

# COMMAND ----------

# DBTITLE 1,Clean product
product_df = (
    spark.table("biovanguard.bronze.src_product")
    .select(
        F.trim("ndc_code").alias("ndc_code"),
        F.trim("brand_name").alias("brand_name"),
        F.trim("dosage_form").alias("dosage_form"),
        F.trim("strength").alias("strength"),
        F.trim("therapeutic_class").alias("therapeutic_class"),
        F.col("wac_price").cast("decimal(10,2)").alias("wac_price"),
    )
    .filter(
        F.col("ndc_code").isNotNull()
        & (F.col("ndc_code") != "")
    )
)

product_df.write.format("delta").mode("overwrite").saveAsTable(
    "biovanguard.silver.slv_product"
)

print("slv_product:", product_df.count(), "rows")

# COMMAND ----------

# DBTITLE 1,Clean Sales Rep header
# MAGIC %md
# MAGIC ## 5. Bronze `src_sales_rep` → Silver `slv_sales_rep` —  SCD2 
# MAGIC
# MAGIC Loads **all** assignment versions (SCD2 history) — never deduplicated here — requiring `rep_emp_id` and `effective_date` to be present.

# COMMAND ----------

# DBTITLE 1,Clean combined sales rep assignments
rep_df = (
    spark.table("biovanguard.bronze.src_sales_rep")
    .select(
        F.trim("rep_emp_id").alias("rep_emp_id"),
        F.trim("rep_name").alias("rep_name"),
        F.trim("territory_code").alias("territory_code"),
        F.trim("region").alias("region"),
        F.trim("role").alias("role"),
        F.to_date("effective_date", "yyyy-MM-dd")
            .alias("effective_date"),
        F.col("source_batch"),
    )
    .filter(
        F.col("rep_emp_id").isNotNull()
        & (F.col("rep_emp_id") != "")
        & F.col("effective_date").isNotNull()
    )
)

rep_df.write.format("delta").mode("overwrite").saveAsTable(
    "biovanguard.silver.slv_sales_rep"
)

print("slv_sales_rep:", rep_df.count(), "rows (all assignment versions)")

# COMMAND ----------

# DBTITLE 1,Clean Prescriptions header
# MAGIC %md
# MAGIC ## 6. Bronze `src_daily_prescriptions` → Silver `slv_daily_prescriptions` — Fact-Grain Staging Table
# MAGIC
# MAGIC The fact-grain transaction table: casts TRx/NRx/units to `int`, `rebate_pct` to `decimal(7,5)` between 0 and 1, and rejects rows with null keys or negative measures.

# COMMAND ----------

# DBTITLE 1,Clean combined daily prescriptions
prescriptions_df = (
    spark.table("biovanguard.bronze.src_daily_prescriptions")
    .select(
        F.to_date("trx_date", "yyyy-MM-dd").alias("trx_date"),
        F.trim("npi_number").alias("npi_number"),
        F.trim("facility_id").alias("facility_id"),
        F.trim("ndc_code").alias("ndc_code"),
        F.trim("rep_emp_id").alias("rep_emp_id"),
        F.trim("channel").alias("channel"),
        F.col("trx_count").cast("int").alias("trx_count"),
        F.col("nrx_count").cast("int").alias("nrx_count"),
        F.col("units_dispensed").cast("int")
            .alias("units_dispensed"),
        F.col("rebate_pct").cast("decimal(7,5)").alias("rebate_pct"),
        F.col("source_batch"),
    )
    .filter(
        F.col("trx_date").isNotNull()
        & F.col("npi_number").isNotNull()
        & F.col("facility_id").isNotNull()
        & F.col("ndc_code").isNotNull()
        & F.col("rep_emp_id").isNotNull()
        & F.col("channel").isNotNull()
        & F.col("trx_count").isNotNull()
        & F.col("nrx_count").isNotNull()
        & F.col("units_dispensed").isNotNull()
        & F.col("rebate_pct").isNotNull()
        & (F.col("trx_count") >= 0)
        & (F.col("nrx_count") >= 0)
        & (F.col("units_dispensed") >= 0)
        & F.col("rebate_pct").between(0, 1)
    )
)

prescriptions_df.write.format("delta").mode("overwrite").saveAsTable(
    "biovanguard.silver.slv_daily_prescriptions"
)

print("slv_daily_prescriptions:", prescriptions_df.count(), "rows")

display(prescriptions_df)

# COMMAND ----------

# DBTITLE 1,Row count summary header
# MAGIC %md
# MAGIC ## 7. Silver Layer Row Count Summary (all `slv_*` target tables)
# MAGIC
# MAGIC Row counts for every silver table after cleansing.

# COMMAND ----------

# DBTITLE 1,Silver row count summary
silver_tables = [
    "slv_calendar",
    "slv_hcp",
    "slv_hco",
    "slv_product",
    "slv_sales_rep",
    "slv_daily_prescriptions",
]

for table_name in silver_tables:
    full_name = f"biovanguard.silver.{table_name}"
    print(full_name, spark.table(full_name).count())

# COMMAND ----------

# DBTITLE 1,Silver validation header
# MAGIC %md
# MAGIC ## 8. Silver Layer — Simple Validation (Bronze `src_*` vs Silver `slv_*`)
# MAGIC
# MAGIC One simple spot check per category — just enough to confirm the transformation is running correctly:
# MAGIC
# MAGIC * **Row count** — bronze vs silver counts on the main table
# MAGIC * **Group by** — rows per transaction date
# MAGIC * **Row check** — 5 sampled rows, source vs silver values
# MAGIC * **Column rule** — product WAC cast
# MAGIC
# MAGIC Fact-level checks (stratification, referential integrity) run in `05_Gold_Fact_Load`.

# COMMAND ----------

# DBTITLE 1,Row count check
# Simple row count check: bronze vs silver on the main table.
src = spark.table("biovanguard.bronze.src_daily_prescriptions").count()
slv = spark.table("biovanguard.silver.slv_daily_prescriptions").count()
print(f"daily_prescriptions: bronze={src}, silver={slv} ->",
      "OK" if src == slv else "MISMATCH")

# COMMAND ----------

# DBTITLE 1,Grouped row count check
# Simple grouped check: rows per transaction date must match.
diff = spark.sql("""
    SELECT COUNT(*) AS mismatched
    FROM (SELECT trx_date, COUNT(*) AS c
          FROM biovanguard.bronze.src_daily_prescriptions GROUP BY trx_date) b
    FULL OUTER JOIN
         (SELECT trx_date, COUNT(*) AS c
          FROM biovanguard.silver.slv_daily_prescriptions GROUP BY trx_date) s
      ON b.trx_date = s.trx_date
    WHERE b.c IS NULL OR s.c IS NULL OR b.c <> s.c
""").collect()[0]["mismatched"]
print("Dates with row-count mismatches:", diff, "->", "OK" if diff == 0 else "FAIL")

# COMMAND ----------

# DBTITLE 1,Sampled row check
# Simple row check: 5 sampled rows, bronze vs silver values.
display(spark.sql("""
    SELECT b.trx_date, b.npi_number, b.ndc_code, b.channel,
           b.trx_count AS bronze_trx, s.trx_count AS silver_trx,
           b.units_dispensed AS bronze_units, s.units_dispensed AS silver_units,
           b.rebate_pct AS bronze_rebate, s.rebate_pct AS silver_rebate
    FROM biovanguard.bronze.src_daily_prescriptions b
    JOIN biovanguard.silver.slv_daily_prescriptions s
      ON s.trx_date = b.trx_date AND s.npi_number = b.npi_number
     AND s.facility_id = b.facility_id AND s.ndc_code = b.ndc_code
     AND s.rep_emp_id = b.rep_emp_id AND s.channel = b.channel
    ORDER BY b.trx_date, b.npi_number
    LIMIT 5
"""))

# COMMAND ----------

# DBTITLE 1,Column rule check
# Simple column check: product WAC cast (bronze string -> silver decimal).
bad = spark.sql("""
    SELECT COUNT(*) AS bad
    FROM biovanguard.bronze.src_product b
    JOIN biovanguard.silver.slv_product s ON s.ndc_code = TRIM(b.ndc_code)
    WHERE s.wac_price <> CAST(b.wac_price AS DECIMAL(10,2))
""").collect()[0]["bad"]
print("Product WAC cast violations:", bad, "->", "OK" if bad == 0 else "FAIL")