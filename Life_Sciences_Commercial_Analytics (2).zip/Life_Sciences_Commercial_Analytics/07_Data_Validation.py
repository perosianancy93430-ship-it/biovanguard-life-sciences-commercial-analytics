# Databricks notebook source
# DBTITLE 1,Data Validation — Title
# MAGIC %md
# MAGIC # BioVanguard Therapeutics — Data Validation (Step 7)
# MAGIC
# MAGIC Runs simple data quality checks across bronze, silver, and gold: table inventory, duplicate fact grains, net sales reconciliation, orphan dimension keys, SCD2 version integrity, and one spot check per testing-document category.
# MAGIC
# MAGIC **Inputs:** all `biovanguard.bronze/silver/gold` tables  
# MAGIC **Outputs:** validation results (expected: all checks clean)

# COMMAND ----------

# DBTITLE 1,Table inventory header
# MAGIC %md
# MAGIC ## 1. Layer Table Inventory (Bronze `src_*` → Silver `slv_*` → Gold `dim_*` / `fact_*`)
# MAGIC
# MAGIC Row counts for every table across the three layers.

# COMMAND ----------

# DBTITLE 1,Layer table inventory
table_inventory = [
    "biovanguard.bronze.src_calendar",
    "biovanguard.bronze.src_hcp",
    "biovanguard.bronze.src_hco",
    "biovanguard.bronze.src_product",
    "biovanguard.bronze.src_sales_rep",
    "biovanguard.bronze.src_daily_prescriptions",
    "biovanguard.silver.slv_calendar",
    "biovanguard.silver.slv_hcp",
    "biovanguard.silver.slv_hco",
    "biovanguard.silver.slv_product",
    "biovanguard.silver.slv_sales_rep",
    "biovanguard.silver.slv_daily_prescriptions",
    "biovanguard.gold.dim_date",
    "biovanguard.gold.dim_hcp",
    "biovanguard.gold.dim_hco",
    "biovanguard.gold.dim_product",
    "biovanguard.gold.dim_sales_rep",
    "biovanguard.gold.fact_daily_commercial_sales",
]

for table_name in table_inventory:
    print(
        table_name,
        spark.table(table_name).count()
    )

# COMMAND ----------

# DBTITLE 1,Duplicate key check header
# MAGIC %md
# MAGIC ## 2. Gold `fact_daily_commercial_sales` — Duplicate Grain Check
# MAGIC
# MAGIC The fact grain (date + HCP + HCO + product + rep version + channel) must be unique — any duplicate would violate the MERGE join condition.

# COMMAND ----------

# DBTITLE 1,Duplicate fact grain check
# MAGIC %sql
# MAGIC -- Duplicates on the fact grain (must return no rows).
# MAGIC SELECT
# MAGIC     Date_Key, HCP_Key, HCO_Key, Product_Key, Rep_Key, Channel_Type,
# MAGIC     COUNT(*) AS Row_Count
# MAGIC FROM biovanguard.gold.fact_daily_commercial_sales
# MAGIC GROUP BY Date_Key, HCP_Key, HCO_Key, Product_Key, Rep_Key, Channel_Type
# MAGIC HAVING COUNT(*) > 1;

# COMMAND ----------

# DBTITLE 1,Net sales check header
# MAGIC %md
# MAGIC ## 3. Gold `fact_daily_commercial_sales` — Net Sales Reconciliation Check
# MAGIC
# MAGIC `Net_Sales_Amount` must equal `Gross_Sales_Amount − Rebate_Amount` (± $0.01).

# COMMAND ----------

# DBTITLE 1,Net sales reconciliation check
# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM biovanguard.gold.fact_daily_commercial_sales
# MAGIC WHERE ABS(
# MAGIC     Net_Sales_Amount
# MAGIC     - (Gross_Sales_Amount - Rebate_Amount)
# MAGIC ) > 0.01;

# COMMAND ----------

# DBTITLE 1,Orphan keys header
# MAGIC %md
# MAGIC ## 4. Gold Fact → All Gold Dimensions — Orphan Key Checks
# MAGIC
# MAGIC Every fact key must resolve to a row in its dimension — all counts must be zero.

# COMMAND ----------

# DBTITLE 1,Orphan dimension key checks
# MAGIC %sql
# MAGIC SELECT 'date' AS Dimension, COUNT(*) AS Orphan_Fact_Keys
# MAGIC FROM biovanguard.gold.fact_daily_commercial_sales f
# MAGIC LEFT ANTI JOIN biovanguard.gold.dim_date d
# MAGIC     ON f.Date_Key = d.Date_Key
# MAGIC UNION ALL
# MAGIC SELECT 'hcp', COUNT(*)
# MAGIC FROM biovanguard.gold.fact_daily_commercial_sales f
# MAGIC LEFT ANTI JOIN biovanguard.gold.dim_hcp h
# MAGIC     ON f.HCP_Key = h.HCP_Key
# MAGIC UNION ALL
# MAGIC SELECT 'hco', COUNT(*)
# MAGIC FROM biovanguard.gold.fact_daily_commercial_sales f
# MAGIC LEFT ANTI JOIN biovanguard.gold.dim_hco o
# MAGIC     ON f.HCO_Key = o.HCO_Key
# MAGIC UNION ALL
# MAGIC SELECT 'product', COUNT(*)
# MAGIC FROM biovanguard.gold.fact_daily_commercial_sales f
# MAGIC LEFT ANTI JOIN biovanguard.gold.dim_product p
# MAGIC     ON f.Product_Key = p.Product_Key
# MAGIC UNION ALL
# MAGIC SELECT 'sales_rep', COUNT(*)
# MAGIC FROM biovanguard.gold.fact_daily_commercial_sales f
# MAGIC LEFT ANTI JOIN biovanguard.gold.dim_sales_rep r
# MAGIC     ON f.Rep_Key = r.Rep_Key;

# COMMAND ----------

# DBTITLE 1,Rep version checks header
# MAGIC %md
# MAGIC ## 5. Gold `dim_sales_rep` — Simple SCD2 Check
# MAGIC
# MAGIC Every representative must have exactly one current version.

# COMMAND ----------

# DBTITLE 1,Simple SCD2 check
from pyspark.sql import functions as F

# Simple SCD2 check: every rep must have exactly one current version.
bad = (
    spark.table("biovanguard.gold.dim_sales_rep")
    .groupBy("Rep_Employee_ID")
    .agg(F.sum(F.when(F.col("Is_Current_Flag") == "Y", 1).otherwise(0)).alias("current_count"))
    .filter(F.col("current_count") != 1)
    .count()
)
print("Reps without exactly one current version:", bad,
      "->", "OK" if bad == 0 else "FAIL")

# COMMAND ----------

# DBTITLE 1,Spot checks header
# MAGIC %md
# MAGIC ## 6. Testing Document Spot Checks (Silver → Gold)
# MAGIC
# MAGIC One simple check per category from **BIOVANGUARD_TESTING_DOCUMENT.xlsx** — just enough to confirm the pipeline runs correctly: row counts, a grouped total, a sampled record, and a column rule.

# COMMAND ----------

# DBTITLE 1,Row count spot check
# MAGIC %sql
# MAGIC -- Row count spot check: silver prescriptions vs gold fact.
# MAGIC SELECT
# MAGIC     (SELECT COUNT(*) FROM biovanguard.silver.slv_daily_prescriptions) AS Silver_Rows,
# MAGIC     (SELECT COUNT(*) FROM biovanguard.gold.fact_daily_commercial_sales) AS Gold_Fact_Rows;

# COMMAND ----------

# DBTITLE 1,Grouped spot check
# MAGIC %sql
# MAGIC -- Grouped spot check: TRx totals by channel, silver vs gold fact.
# MAGIC SELECT
# MAGIC     COALESCE(s.channel, f.channel) AS Channel,
# MAGIC     s.silver_trx AS Silver_TRx,
# MAGIC     f.gold_trx AS Gold_TRx
# MAGIC FROM (SELECT channel, SUM(trx_count) AS silver_trx
# MAGIC       FROM biovanguard.silver.slv_daily_prescriptions GROUP BY channel) s
# MAGIC FULL OUTER JOIN
# MAGIC      (SELECT Channel_Type AS channel, SUM(TRx_Count) AS gold_trx
# MAGIC       FROM biovanguard.gold.fact_daily_commercial_sales GROUP BY Channel_Type) f
# MAGIC   ON s.channel = f.channel
# MAGIC ORDER BY Channel;

# COMMAND ----------

# DBTITLE 1,Sampled record check
# MAGIC %sql
# MAGIC -- Sampled record check: 5 fact rows joined back to their natural keys.
# MAGIC WITH fact5 AS (
# MAGIC     SELECT F.TRx_Count, F.Units_Dispensed, F.Gross_Sales_Amount, F.Net_Sales_Amount,
# MAGIC            D.Calendar_Date, H.NPI_Number, O.Facility_ID, P.NDC_Code,
# MAGIC            R.Rep_Employee_ID, F.Channel_Type
# MAGIC     FROM biovanguard.gold.fact_daily_commercial_sales F
# MAGIC     JOIN biovanguard.gold.dim_date D ON F.Date_Key = D.Date_Key
# MAGIC     JOIN biovanguard.gold.dim_hcp H ON F.HCP_Key = H.HCP_Key
# MAGIC     JOIN biovanguard.gold.dim_hco O ON F.HCO_Key = O.HCO_Key
# MAGIC     JOIN biovanguard.gold.dim_product P ON F.Product_Key = P.Product_Key
# MAGIC     JOIN biovanguard.gold.dim_sales_rep R ON F.Rep_Key = R.Rep_Key
# MAGIC     ORDER BY D.Calendar_Date, H.NPI_Number, P.NDC_Code
# MAGIC     LIMIT 5
# MAGIC )
# MAGIC SELECT f.*, s.trx_count AS Silver_TRx, s.units_dispensed AS Silver_Units
# MAGIC FROM fact5 f
# MAGIC JOIN biovanguard.silver.slv_daily_prescriptions s
# MAGIC   ON s.trx_date = f.Calendar_Date AND s.npi_number = f.NPI_Number
# MAGIC  AND s.facility_id = f.Facility_ID AND s.ndc_code = f.NDC_Code
# MAGIC  AND s.rep_emp_id = f.Rep_Employee_ID AND s.channel = f.Channel_Type;

# COMMAND ----------

# DBTITLE 1,Column rule spot check
# MAGIC %sql
# MAGIC -- Column-rule spot check: dim_product attributes must equal the silver source.
# MAGIC SELECT COUNT(*) AS Mismatched_Products
# MAGIC FROM biovanguard.gold.dim_product d
# MAGIC LEFT JOIN biovanguard.silver.slv_product s
# MAGIC   ON d.NDC_Code = s.ndc_code
# MAGIC WHERE s.ndc_code IS NULL
# MAGIC    OR d.Brand_Name <> s.brand_name
# MAGIC    OR d.WAC_Price <> s.wac_price;

# COMMAND ----------

# DBTITLE 1,REF_INT — combined referential integrity test
# MAGIC %sql
# MAGIC -- REF_INT_SRC_TGT6 : REFERENTIAL INTEGRITY TEST — combined orphan check across all five dimensions
# MAGIC SELECT COUNT(*) AS Orphan_Records,
# MAGIC        CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END AS Pass_Fail
# MAGIC FROM biovanguard.gold.fact_daily_commercial_sales F
# MAGIC LEFT JOIN biovanguard.gold.dim_date DD      ON F.Date_Key = DD.Date_Key
# MAGIC LEFT JOIN biovanguard.gold.dim_product DP    ON F.Product_Key = DP.Product_Key
# MAGIC LEFT JOIN biovanguard.gold.dim_hcp DH        ON F.HCP_Key = DH.HCP_Key
# MAGIC LEFT JOIN biovanguard.gold.dim_hco DO_       ON F.HCO_Key = DO_.HCO_Key
# MAGIC LEFT JOIN biovanguard.gold.dim_sales_rep DR ON F.Rep_Key = DR.Rep_Key
# MAGIC WHERE DD.Date_Key IS NULL
# MAGIC    OR DP.Product_Key IS NULL
# MAGIC    OR DH.HCP_Key IS NULL
# MAGIC    OR DO_.HCO_Key IS NULL
# MAGIC    OR DR.Rep_Key IS NULL;