# Databricks notebook source
# DBTITLE 1,Business Analytics Views — Title
# MAGIC %md
# MAGIC # BioVanguard Therapeutics — Business Analytics Views (Step 6)
# MAGIC
# MAGIC Creates the gold reporting views — executive KPIs, product/channel/HCP/HCO/territory
# MAGIC performance, historical rep assignments, and pipeline validation — consumed by the
# MAGIC commercial analytics dashboard. The gold fact stores the dimension keys, raw measures,
# MAGIC and the documented revenue measures (Gross = Units × WAC, Rebate = Gross × Rebate %,
# MAGIC Net = Gross − Rebate); the views aggregate them, joining dimensions only for attributes.
# MAGIC WAC and rebate % are never stored.
# MAGIC
# MAGIC **Inputs:** `biovanguard.gold.fact_daily_commercial_sales` + gold dimensions  
# MAGIC **Outputs:** `biovanguard.gold.vw_*` reporting views

# COMMAND ----------

# DBTITLE 1,Section 1 header
# MAGIC %md
# MAGIC ## 1. Gold Fact `fact_daily_commercial_sales` → Views `vw_executive_commercial_summary`, `vw_product_performance`
# MAGIC
# MAGIC Creates `vw_executive_commercial_summary` (portfolio KPIs) and `vw_product_performance` (brand-level performance).

# COMMAND ----------

# DBTITLE 1,Executive summary and product performance views
# MAGIC %sql
# MAGIC -- Executive overview and product performance reporting views.
# MAGIC -- Revenue measures (Gross / Rebate / Net) are stored on the fact per
# MAGIC -- the documented definitions; the views just aggregate them.
# MAGIC ALTER VIEW biovanguard.gold.vw_executive_commercial_summary AS
# MAGIC SELECT
# MAGIC     SUM(f.TRx_Count) AS Total_TRx,
# MAGIC     SUM(f.NRx_Count) AS Total_NRx,
# MAGIC     SUM(f.Units_Dispensed) AS Total_Units_Dispensed,
# MAGIC     ROUND(SUM(f.Gross_Sales_Amount), 2) AS Total_Gross_Sales,
# MAGIC     ROUND(SUM(f.Net_Sales_Amount), 2) AS Total_Net_Sales,
# MAGIC     COUNT(*) AS Fact_Records,
# MAGIC     MIN(d.Calendar_Date) AS From_Date,
# MAGIC     MAX(d.Calendar_Date) AS To_Date
# MAGIC FROM biovanguard.gold.fact_daily_commercial_sales f
# MAGIC JOIN biovanguard.gold.dim_date d
# MAGIC     ON f.Date_Key = d.Date_Key;
# MAGIC
# MAGIC ALTER VIEW biovanguard.gold.vw_product_performance AS
# MAGIC SELECT
# MAGIC     p.Brand_Name,
# MAGIC     p.NDC_Code,
# MAGIC     p.Dosage_Form,
# MAGIC     p.Strength,
# MAGIC     p.Therapeutic_Class,
# MAGIC     SUM(f.TRx_Count) AS Total_TRx,
# MAGIC     SUM(f.NRx_Count) AS Total_NRx,
# MAGIC     SUM(f.Units_Dispensed) AS Total_Units_Dispensed,
# MAGIC     ROUND(SUM(f.Gross_Sales_Amount), 2) AS Gross_Sales,
# MAGIC     ROUND(SUM(f.Rebate_Amount), 2) AS Rebate_Amount,
# MAGIC     ROUND(SUM(f.Net_Sales_Amount), 2) AS Net_Sales
# MAGIC FROM biovanguard.gold.fact_daily_commercial_sales f
# MAGIC JOIN biovanguard.gold.dim_product p
# MAGIC     ON f.Product_Key = p.Product_Key
# MAGIC GROUP BY
# MAGIC     p.Brand_Name,
# MAGIC     p.NDC_Code,
# MAGIC     p.Dosage_Form,
# MAGIC     p.Strength,
# MAGIC     p.Therapeutic_Class;
# MAGIC

# COMMAND ----------

# DBTITLE 1,Section 2 header
# MAGIC %md
# MAGIC ## 2. Gold Fact `fact_daily_commercial_sales` → Views `vw_channel_performance`, `vw_hcp_performance`
# MAGIC
# MAGIC Creates `vw_channel_performance` and `vw_hcp_performance`. Fact rows are daily transaction records — `Avg_Net_Sales_Per_Daily_Record` reflects that grain.

# COMMAND ----------

# DBTITLE 1,Channel and HCP performance views
# MAGIC %sql
# MAGIC -- Channel view: fact rows are daily transaction records, not individual
# MAGIC -- interactions; Avg_Net_Sales_Per_Daily_Record reflects that grain.
# MAGIC -- Revenue measures are stored on the fact and simply aggregated.
# MAGIC ALTER VIEW biovanguard.gold.vw_channel_performance AS
# MAGIC SELECT
# MAGIC     Channel_Type,
# MAGIC     SUM(TRx_Count) AS Total_TRx,
# MAGIC     SUM(NRx_Count) AS Total_NRx,
# MAGIC     SUM(Units_Dispensed) AS Total_Units_Dispensed,
# MAGIC     ROUND(SUM(Gross_Sales_Amount), 2) AS Gross_Sales,
# MAGIC     ROUND(SUM(Net_Sales_Amount), 2) AS Net_Sales,
# MAGIC     COUNT(*) AS Daily_Transaction_Records,
# MAGIC     ROUND(AVG(Net_Sales_Amount), 2) AS Avg_Net_Sales_Per_Daily_Record
# MAGIC FROM biovanguard.gold.fact_daily_commercial_sales
# MAGIC GROUP BY Channel_Type;
# MAGIC
# MAGIC ALTER VIEW biovanguard.gold.vw_hcp_performance AS
# MAGIC SELECT
# MAGIC     h.HCP_Key,
# MAGIC     h.NPI_Number,
# MAGIC     h.First_Name,
# MAGIC     h.Last_Name,
# MAGIC     h.Specialty,
# MAGIC     SUM(f.TRx_Count) AS Total_TRx,
# MAGIC     SUM(f.NRx_Count) AS Total_NRx,
# MAGIC     ROUND(SUM(f.Gross_Sales_Amount), 2) AS Gross_Sales,
# MAGIC     ROUND(SUM(f.Net_Sales_Amount), 2) AS Net_Sales
# MAGIC FROM biovanguard.gold.fact_daily_commercial_sales f
# MAGIC JOIN biovanguard.gold.dim_hcp h
# MAGIC     ON f.HCP_Key = h.HCP_Key
# MAGIC GROUP BY
# MAGIC     h.HCP_Key,
# MAGIC     h.NPI_Number,
# MAGIC     h.First_Name,
# MAGIC     h.Last_Name,
# MAGIC     h.Specialty;
# MAGIC

# COMMAND ----------

# DBTITLE 1,Section 3 header
# MAGIC %md
# MAGIC ## 3. Gold Fact + `dim_hco` / `dim_sales_rep` → Views `vw_hco_performance`, `vw_territory_performance` (SCD2 Attribution)
# MAGIC
# MAGIC Creates `vw_hco_performance` and `vw_territory_performance`; territory view joins on the historical `Rep_Key`, keeping sales attributed to the territory version effective on the transaction date.

# COMMAND ----------

# DBTITLE 1,HCO and territory performance views
# MAGIC %sql
# MAGIC -- Revenue measures are stored on the fact and simply aggregated.
# MAGIC ALTER VIEW biovanguard.gold.vw_hco_performance AS
# MAGIC SELECT
# MAGIC     o.HCO_Key,
# MAGIC     o.Facility_ID,
# MAGIC     o.Facility_Name,
# MAGIC     o.Facility_Type,
# MAGIC     o.City,
# MAGIC     o.State,
# MAGIC     SUM(f.TRx_Count) AS Total_TRx,
# MAGIC     SUM(f.NRx_Count) AS Total_NRx,
# MAGIC     SUM(f.Units_Dispensed) AS Total_Units_Dispensed,
# MAGIC     ROUND(SUM(f.Gross_Sales_Amount), 2) AS Gross_Sales,
# MAGIC     ROUND(SUM(f.Net_Sales_Amount), 2) AS Net_Sales
# MAGIC FROM biovanguard.gold.fact_daily_commercial_sales f
# MAGIC JOIN biovanguard.gold.dim_hco o
# MAGIC     ON f.HCO_Key = o.HCO_Key
# MAGIC GROUP BY
# MAGIC     o.HCO_Key,
# MAGIC     o.Facility_ID,
# MAGIC     o.Facility_Name,
# MAGIC     o.Facility_Type,
# MAGIC     o.City,
# MAGIC     o.State;
# MAGIC
# MAGIC -- Territory performance joins the fact table on the historical Rep_Key,
# MAGIC -- so sales stay attributed to the territory version effective on the
# MAGIC -- transaction date (SCD Type 2 historical truth).
# MAGIC ALTER VIEW biovanguard.gold.vw_territory_performance AS
# MAGIC SELECT
# MAGIC     r.Rep_Key,
# MAGIC     r.Rep_Employee_ID,
# MAGIC     r.Rep_Name,
# MAGIC     r.Territory_Code,
# MAGIC     r.Region,
# MAGIC     r.Is_Current_Flag,
# MAGIC     r.Effective_Start_Date,
# MAGIC     r.Effective_End_Date,
# MAGIC     SUM(f.TRx_Count) AS Total_TRx,
# MAGIC     ROUND(SUM(f.Gross_Sales_Amount), 2) AS Gross_Sales,
# MAGIC     ROUND(SUM(f.Net_Sales_Amount), 2) AS Net_Sales
# MAGIC FROM biovanguard.gold.fact_daily_commercial_sales f
# MAGIC JOIN biovanguard.gold.dim_sales_rep r
# MAGIC     ON f.Rep_Key = r.Rep_Key
# MAGIC GROUP BY
# MAGIC     r.Rep_Key,
# MAGIC     r.Rep_Employee_ID,
# MAGIC     r.Rep_Name,
# MAGIC     r.Territory_Code,
# MAGIC     r.Region,
# MAGIC     r.Is_Current_Flag,
# MAGIC     r.Effective_Start_Date,
# MAGIC     r.Effective_End_Date;
# MAGIC

# COMMAND ----------

# DBTITLE 1,Section 4 header
# MAGIC %md
# MAGIC ## 4. Gold `dim_sales_rep` + Fact → Views `vw_historical_rep_assignments`, `vw_pipeline_validation`
# MAGIC
# MAGIC Creates `vw_historical_rep_assignments` (full SCD2 assignment history) and `vw_pipeline_validation` (self-serve data quality counters).

# COMMAND ----------

# DBTITLE 1,Historical assignments and pipeline validation views
# MAGIC %sql
# MAGIC ALTER VIEW biovanguard.gold.vw_historical_rep_assignments AS
# MAGIC SELECT
# MAGIC     Rep_Key,
# MAGIC     Rep_Employee_ID,
# MAGIC     Rep_Name,
# MAGIC     Territory_Code,
# MAGIC     Region,
# MAGIC     Role,
# MAGIC     Effective_Start_Date,
# MAGIC     Effective_End_Date,
# MAGIC     Is_Current_Flag
# MAGIC FROM biovanguard.gold.dim_sales_rep;
# MAGIC
# MAGIC -- Fact grain = Date_Key + HCP_Key + HCO_Key + Product_Key + Rep_Key + Channel_Type
# MAGIC ALTER VIEW biovanguard.gold.vw_pipeline_validation AS
# MAGIC SELECT 'fact_row_count' AS Check_Name,
# MAGIC        CAST(COUNT(*) AS STRING) AS Check_Value
# MAGIC FROM biovanguard.gold.fact_daily_commercial_sales
# MAGIC UNION ALL
# MAGIC SELECT 'distinct_fact_grains',
# MAGIC        CAST(COUNT(*) AS STRING)
# MAGIC FROM (
# MAGIC     SELECT Date_Key, HCP_Key, HCO_Key, Product_Key, Rep_Key, Channel_Type
# MAGIC     FROM biovanguard.gold.fact_daily_commercial_sales
# MAGIC     GROUP BY Date_Key, HCP_Key, HCO_Key, Product_Key, Rep_Key, Channel_Type
# MAGIC )
# MAGIC UNION ALL
# MAGIC SELECT 'duplicate_fact_grains', CAST(COUNT(*) AS STRING)
# MAGIC FROM (
# MAGIC     SELECT Date_Key, HCP_Key, HCO_Key, Product_Key, Rep_Key, Channel_Type
# MAGIC     FROM biovanguard.gold.fact_daily_commercial_sales
# MAGIC     GROUP BY Date_Key, HCP_Key, HCO_Key, Product_Key, Rep_Key, Channel_Type
# MAGIC     HAVING COUNT(*) > 1
# MAGIC )
# MAGIC UNION ALL
# MAGIC SELECT 'orphan_date_keys', CAST(COUNT(*) AS STRING)
# MAGIC FROM biovanguard.gold.fact_daily_commercial_sales f
# MAGIC LEFT ANTI JOIN biovanguard.gold.dim_date d
# MAGIC     ON f.Date_Key = d.Date_Key
# MAGIC UNION ALL
# MAGIC SELECT 'orphan_hcp_keys', CAST(COUNT(*) AS STRING)
# MAGIC FROM biovanguard.gold.fact_daily_commercial_sales f
# MAGIC LEFT ANTI JOIN biovanguard.gold.dim_hcp h
# MAGIC     ON f.HCP_Key = h.HCP_Key
# MAGIC UNION ALL
# MAGIC SELECT 'orphan_hco_keys', CAST(COUNT(*) AS STRING)
# MAGIC FROM biovanguard.gold.fact_daily_commercial_sales f
# MAGIC LEFT ANTI JOIN biovanguard.gold.dim_hco o
# MAGIC     ON f.HCO_Key = o.HCO_Key
# MAGIC UNION ALL
# MAGIC SELECT 'orphan_product_keys', CAST(COUNT(*) AS STRING)
# MAGIC FROM biovanguard.gold.fact_daily_commercial_sales f
# MAGIC LEFT ANTI JOIN biovanguard.gold.dim_product p
# MAGIC     ON f.Product_Key = p.Product_Key
# MAGIC UNION ALL
# MAGIC SELECT 'orphan_rep_keys', CAST(COUNT(*) AS STRING)
# MAGIC FROM biovanguard.gold.fact_daily_commercial_sales f
# MAGIC LEFT ANTI JOIN biovanguard.gold.dim_sales_rep r
# MAGIC     ON f.Rep_Key = r.Rep_Key
# MAGIC UNION ALL
# MAGIC SELECT 'active_sales_reps', CAST(COUNT(*) AS STRING)
# MAGIC FROM biovanguard.gold.dim_sales_rep
# MAGIC WHERE Is_Current_Flag = 'Y'
# MAGIC UNION ALL
# MAGIC SELECT 'invalid_effective_dates', CAST(COUNT(*) AS STRING)
# MAGIC FROM biovanguard.gold.dim_sales_rep
# MAGIC WHERE Effective_Start_Date > Effective_End_Date
# MAGIC UNION ALL
# MAGIC SELECT 'fact_vs_source_row_diff', CAST(
# MAGIC     (SELECT COUNT(*) FROM biovanguard.gold.fact_daily_commercial_sales)
# MAGIC     - (SELECT COUNT(*) FROM biovanguard.silver.slv_daily_prescriptions) AS STRING);
# MAGIC

# COMMAND ----------

# DBTITLE 1,Section 5 header
# MAGIC %md
# MAGIC ## 5. Preview Gold Views `vw_executive_commercial_summary` & `vw_territory_performance`
# MAGIC
# MAGIC Sanity-checks the executive summary and territory performance views.

# COMMAND ----------

# DBTITLE 1,Preview reporting views
display(spark.table("biovanguard.gold.vw_executive_commercial_summary"))

display(spark.table("biovanguard.gold.vw_territory_performance"))

# COMMAND ----------

# DBTITLE 1,Revenue reconciliation header
# MAGIC %md
# MAGIC ## 6. Revenue Reconciliation — Stored Fact Measures vs Source-Derived Totals
# MAGIC
# MAGIC The fact stores the documented revenue measures (Gross = Units × WAC, Rebate = Gross × Rebate %, Net = Gross − Rebate). This check proves the stored fact totals equal the amounts derived directly from the silver source (Units × WAC from `dim_product`, × rebate % from silver).

# COMMAND ----------

# DBTITLE 1,Revenue reconciliation check
# Stored fact measures — what the reporting views aggregate.
computed = spark.sql("""
    SELECT
        ROUND(SUM(Gross_Sales_Amount), 2) AS Gross,
        ROUND(SUM(Rebate_Amount), 2) AS Rebate,
        ROUND(SUM(Net_Sales_Amount), 2) AS Net
    FROM biovanguard.gold.fact_daily_commercial_sales
""").collect()[0]

# Reference: totals derived directly from the silver source + product WAC
# (same formulas as the documented definitions).
reference = spark.sql("""
    SELECT
        ROUND(SUM(s.units_dispensed * p.WAC_Price), 2) AS Gross,
        ROUND(SUM(ROUND(s.units_dispensed * p.WAC_Price * s.rebate_pct, 2)), 2) AS Rebate,
        ROUND(SUM(
            ROUND(s.units_dispensed * p.WAC_Price, 2)
            - ROUND(s.units_dispensed * p.WAC_Price * s.rebate_pct, 2)
        ), 2) AS Net
    FROM biovanguard.silver.slv_daily_prescriptions s
    JOIN biovanguard.gold.dim_product p
        ON s.ndc_code = p.NDC_Code
""").collect()[0]

recon = spark.createDataFrame(
    [(m, float(computed[m]), float(reference[m]),
      abs(float(computed[m]) - float(reference[m])) <= 0.01)
     for m in ("Gross", "Rebate", "Net")],
    ["Measure", "Stored_In_Fact", "Derived_From_Source", "Match"],
)
display(recon)