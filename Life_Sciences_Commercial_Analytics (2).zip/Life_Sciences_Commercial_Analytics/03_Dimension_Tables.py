# Databricks notebook source
# DBTITLE 1,Dimension Tables — Title
# MAGIC %md
# MAGIC # BioVanguard Therapeutics — Gold Dimension Tables (Step 3)
# MAGIC
# MAGIC Builds the conformed gold dimensions from the silver layer, assigning surrogate keys to each.
# MAGIC
# MAGIC **Inputs:** `biovanguard.silver.slv_calendar`, `slv_hcp`, `slv_hco`, `slv_product`  
# MAGIC **Outputs:** `biovanguard.gold.dim_date`, `dim_hcp`, `dim_hco`, `dim_product`

# COMMAND ----------

# DBTITLE 1,Dim_Date header
# MAGIC %md
# MAGIC ## 1. Silver `slv_calendar` → Gold `biovanguard.gold.dim_date` — Dim_Date
# MAGIC
# MAGIC Derives `Date_Key` (yyyyMMdd int) and defaults `Is_Holiday` to `'N'` (source carries no holiday attribute). Includes the shared imports.

# COMMAND ----------

# DBTITLE 1,Dim_Date with Is_Holiday default
from pyspark.sql import functions as F
from pyspark.sql.window import Window

calendar_source = spark.table(
    "biovanguard.silver.slv_calendar"
)

dim_date = (
    calendar_source
    .select(
        F.date_format("calendar_date", "yyyyMMdd")
            .cast("int").alias("Date_Key"),
        F.col("calendar_date").alias("Calendar_Date"),
        F.col("day_of_week").alias("Day_Of_Week"),
        F.col("day_name").alias("Day_Name"),
        F.col("month_number").alias("Month_Number"),
        F.col("month_name").alias("Month_Name"),
        F.col("quarter").alias("Quarter"),
        F.col("year").alias("Year"),
        F.col("is_weekend").alias("Is_Weekend"),
        # Source calendar carries no holiday attribute; Is_Holiday is
        # defaulted to 'N' (documented limitation).
        F.lit("N").alias("Is_Holiday")
    )
)

dim_date.write.format("delta").mode("overwrite").saveAsTable(
    "biovanguard.gold.dim_date"
)

display(dim_date)

# COMMAND ----------

# DBTITLE 1,Dim_HCP header
# MAGIC %md
# MAGIC ## 2. Silver `slv_hcp` → Gold `biovanguard.gold.dim_hcp` — Dim_HCP
# MAGIC
# MAGIC Assigns the surrogate `HCP_Key` by row number ordered on `npi_number`.

# COMMAND ----------

# DBTITLE 1,Dim_HCP
hcp_source = spark.table(
    "biovanguard.silver.slv_hcp"
)

hcp_window = Window.orderBy("npi_number")

dim_hcp = (
    hcp_source
    .withColumn(
        "HCP_Key",
        F.row_number().over(hcp_window)
    )
    .select(
        "HCP_Key",
        F.col("npi_number").alias("NPI_Number"),
        F.col("first_name").alias("First_Name"),
        F.col("last_name").alias("Last_Name"),
        F.col("specialty").alias("Specialty"),
        F.col("state_license_number")
            .alias("State_License_Number")
    )
)

dim_hcp.write.format("delta").mode("overwrite").saveAsTable(
    "biovanguard.gold.dim_hcp"
)

display(dim_hcp)

# COMMAND ----------

# DBTITLE 1,Dim_HCO header
# MAGIC %md
# MAGIC ## 3. Silver `slv_hco` → Gold `biovanguard.gold.dim_hco` — Dim_HCO
# MAGIC
# MAGIC Assigns the surrogate `HCO_Key` by row number ordered on `facility_id`.

# COMMAND ----------

# DBTITLE 1,Dim_HCO
hco_source = spark.table(
    "biovanguard.silver.slv_hco"
)

hco_window = Window.orderBy("facility_id")

dim_hco = (
    hco_source
    .withColumn(
        "HCO_Key",
        F.row_number().over(hco_window)
    )
    .select(
        "HCO_Key",
        F.col("facility_id").alias("Facility_ID"),
        F.col("facility_name").alias("Facility_Name"),
        F.col("facility_type").alias("Facility_Type"),
        F.col("city").alias("City"),
        F.col("state").alias("State"),
        F.col("zip_code").alias("Zip_Code")
    )
)

dim_hco.write.format("delta").mode("overwrite").saveAsTable(
    "biovanguard.gold.dim_hco"
)

display(dim_hco)

# COMMAND ----------

# DBTITLE 1,Dim_Product header
# MAGIC %md
# MAGIC ## 4. Silver `slv_product` → Gold `biovanguard.gold.dim_product` — Dim_Product
# MAGIC
# MAGIC Assigns the surrogate `Product_Key` by row number ordered on `ndc_code`.

# COMMAND ----------

# DBTITLE 1,Dim_Product
product_source = spark.table(
    "biovanguard.silver.slv_product"
)

product_window = Window.orderBy("ndc_code")

dim_product = (
    product_source
    .withColumn(
        "Product_Key",
        F.row_number().over(product_window)
    )
    .select(
        "Product_Key",
        F.col("ndc_code").alias("NDC_Code"),
        F.col("brand_name").alias("Brand_Name"),
        F.col("dosage_form").alias("Dosage_Form"),
        F.col("strength").alias("Strength"),
        F.col("therapeutic_class").alias("Therapeutic_Class"),
        F.col("wac_price").alias("WAC_Price")
    )
)

dim_product.write.format("delta").mode("overwrite").saveAsTable(
    "biovanguard.gold.dim_product"
)

display(dim_product)

# COMMAND ----------

# DBTITLE 1,Row counts header
# MAGIC %md
# MAGIC ## 5. Gold Dimension Row Count Summary (all `dim_*` target tables)
# MAGIC
# MAGIC Row counts for all four dimensions built in this notebook.

# COMMAND ----------

# DBTITLE 1,Dimension row counts
for table_name in [
    "biovanguard.gold.dim_date",
    "biovanguard.gold.dim_hcp",
    "biovanguard.gold.dim_hco",
    "biovanguard.gold.dim_product"
]:
    print(table_name, spark.table(table_name).count())