# Databricks notebook source
# DBTITLE 1,SCD2 Sales Rep — Title
# MAGIC %md
# MAGIC # BioVanguard Therapeutics — SCD2 Sales Rep Dimension (Step 4)
# MAGIC
# MAGIC Builds the Slowly Changing Dimension Type 2 sales-rep dimension, preserving **every** territory-assignment version with effective dates and a current flag, so historical sales keep their correct territory attribution.
# MAGIC
# MAGIC **Inputs:** `biovanguard.silver.slv_sales_rep`  
# MAGIC **Outputs:** `biovanguard.gold.dim_sales_rep`

# COMMAND ----------

# DBTITLE 1,Load rep assignments header
# MAGIC %md
# MAGIC ## 1. Source: Silver `biovanguard.silver.slv_sales_rep` — Load All Assignment Versions
# MAGIC
# MAGIC Loads all assignment versions (initial + delta batches) from `slv_sales_rep`.

# COMMAND ----------

# DBTITLE 1,Load combined rep assignments from silver
from pyspark.sql import functions as F
from pyspark.sql.window import Window

# Silver holds a single combined rep-assignment table
# (initial + delta batches) built by notebook 02.
all_rep_versions = spark.table(
    "biovanguard.silver.slv_sales_rep"
)

display(
    all_rep_versions.orderBy(
        "rep_emp_id",
        "effective_date"
    )
)

# COMMAND ----------

# DBTITLE 1,SCD2 history header
# MAGIC %md
# MAGIC ## 2. Staging: Build SCD2 Version History (Effective Dates & Current Flag)
# MAGIC
# MAGIC Derives `Effective_End_Date` (next version start − 1, or 9999-12-31 for the current version) and `Is_Current_Flag`.

# COMMAND ----------

rep_window = (
    Window
    .partitionBy("rep_emp_id")
    .orderBy("effective_date")
)

rep_history = (
    all_rep_versions
    .withColumn(
        "next_effective_date",
        F.lead("effective_date").over(rep_window)
    )
    .withColumn(
        "Effective_Start_Date",
        F.col("effective_date")
    )
    .withColumn(
        "Effective_End_Date",
        F.when(
            F.col("next_effective_date").isNotNull(),
            F.date_sub("next_effective_date", 1)
        ).otherwise(
            F.to_date(F.lit("9999-12-31"))
        )
    )
    .withColumn(
        "Is_Current_Flag",
        F.when(
            F.col("next_effective_date").isNull(),
            "Y"
        ).otherwise("N")
    )
    .drop("effective_date", "next_effective_date")
)

display(
    rep_history.orderBy(
        "rep_emp_id",
        "Effective_Start_Date"
    )
)

# COMMAND ----------

# DBTITLE 1,Save dim header
# MAGIC %md
# MAGIC ## 3. Staging `rep_history` → Gold `biovanguard.gold.dim_sales_rep`: Assign `Rep_Key` & Incremental MERGE
# MAGIC
# MAGIC One `Rep_Key` per assignment version, ordered by rep and effective start date. Upserts into the gold dimension via Delta MERGE matched on `Rep_Employee_ID + Effective_Start_Date` — existing rows are updated if attributes changed, new versions are inserted (no full overwrite).

# COMMAND ----------

# DBTITLE 1,Save dim_sales_rep to gold
from delta.tables import DeltaTable

rep_key_window = Window.orderBy(
    "rep_emp_id",
    "Effective_Start_Date"
)

dim_sales_rep = (
    rep_history
    .withColumn(
        "Rep_Key",
        F.row_number().over(rep_key_window)
    )
    .select(
        "Rep_Key",
        F.col("rep_emp_id").alias("Rep_Employee_ID"),
        F.col("rep_name").alias("Rep_Name"),
        F.col("territory_code").alias("Territory_Code"),
        F.col("region").alias("Region"),
        F.col("role").alias("Role"),
        "Effective_Start_Date",
        "Effective_End_Date",
        "Is_Current_Flag"
    )
)

# Ensure the gold dimension table exists (schema-only create on first run)
(
    dim_sales_rep
    .limit(0)
    .write
    .format("delta")
    .mode("ignore")
    .saveAsTable("biovanguard.gold.dim_sales_rep")
)

# Incremental MERGE: upsert version rows matched on the natural
# business key (Rep_Employee_ID + Effective_Start_Date). Existing
# rows are updated if any attribute changed; new versions are
# inserted — no full overwrite, preserving table history.
dim_target = DeltaTable.forName(spark, "biovanguard.gold.dim_sales_rep")

(
    dim_target.alias("t")
    .merge(
        dim_sales_rep.alias("s"),
        """
            t.Rep_Employee_ID = s.Rep_Employee_ID
            AND t.Effective_Start_Date = s.Effective_Start_Date
        """,
    )
    .whenMatchedUpdateAll()
    .whenNotMatchedInsertAll()
    .execute()
)

print(f"dim_sales_rep rows after MERGE: {spark.table('biovanguard.gold.dim_sales_rep').count()}")

display(
    spark.table("biovanguard.gold.dim_sales_rep").orderBy(
        "Rep_Employee_ID",
        "Effective_Start_Date"
    )
)

# COMMAND ----------

# DBTITLE 1,Verify SCD2 header
# MAGIC %md
# MAGIC ## 4. Verify Gold `dim_sales_rep` Output
# MAGIC
# MAGIC Reviews the saved dimension — every rep shows one row per assignment version with continuous effective dates.

# COMMAND ----------

# DBTITLE 1,Verify SCD2 output
# MAGIC %sql
# MAGIC SELECT
# MAGIC     Rep_Employee_ID,
# MAGIC     Rep_Name,
# MAGIC     Territory_Code,
# MAGIC     Region,
# MAGIC     Effective_Start_Date,
# MAGIC     Effective_End_Date,
# MAGIC     Is_Current_Flag
# MAGIC FROM biovanguard.gold.dim_sales_rep
# MAGIC ORDER BY Rep_Employee_ID, Effective_Start_Date;

# COMMAND ----------

# DBTITLE 1,One current version header
# MAGIC %md
# MAGIC ## 5. Check on Gold `dim_sales_rep`: Exactly One Current Version per Rep
# MAGIC
# MAGIC Every representative must have exactly one `Is_Current_Flag = 'Y'` version — expected result: no rows.

# COMMAND ----------

# DBTITLE 1,Exactly one current version per rep
# MAGIC %sql
# MAGIC SELECT
# MAGIC     Rep_Employee_ID,
# MAGIC     SUM(
# MAGIC         CASE
# MAGIC             WHEN Is_Current_Flag = 'Y' THEN 1
# MAGIC             ELSE 0
# MAGIC         END
# MAGIC     ) AS Current_Version_Count
# MAGIC FROM biovanguard.gold.dim_sales_rep
# MAGIC GROUP BY Rep_Employee_ID
# MAGIC HAVING SUM(
# MAGIC     CASE
# MAGIC         WHEN Is_Current_Flag = 'Y' THEN 1
# MAGIC         ELSE 0
# MAGIC     END
# MAGIC ) <> 1;

# COMMAND ----------

# DBTITLE 1,No overlaps header
# MAGIC %md
# MAGIC ## 6. Check on Gold `dim_sales_rep`: No Overlapping Effective Periods
# MAGIC
# MAGIC Version periods must not overlap — expected result: no rows.

# COMMAND ----------

# DBTITLE 1,No overlapping effective periods
# MAGIC %sql
# MAGIC SELECT
# MAGIC     a.Rep_Employee_ID,
# MAGIC     a.Rep_Key AS First_Rep_Key,
# MAGIC     b.Rep_Key AS Second_Rep_Key
# MAGIC FROM biovanguard.gold.dim_sales_rep a
# MAGIC JOIN biovanguard.gold.dim_sales_rep b
# MAGIC     ON a.Rep_Employee_ID = b.Rep_Employee_ID
# MAGIC    AND a.Rep_Key < b.Rep_Key
# MAGIC    AND a.Effective_Start_Date <= b.Effective_End_Date
# MAGIC    AND b.Effective_Start_Date <= a.Effective_End_Date;