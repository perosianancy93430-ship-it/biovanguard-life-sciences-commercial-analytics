# Databricks notebook source
# DBTITLE 1,Project Setup — Title
# MAGIC %md
# MAGIC ## # BioVanguard Therapeutics 
# MAGIC
# MAGIC Verifies the environment and locates the raw source files in the bronze landing volume before ingestion.
# MAGIC
# MAGIC **Inputs:** `/Volumes/biovanguard/bronze/landing/`  
# MAGIC **Outputs:** none (environment & file exploration)

# COMMAND ----------

# DBTITLE 1,Environment Check header
# MAGIC %md
# MAGIC ## 1. Environment Check
# MAGIC
# MAGIC Confirms the project identity and Spark version.

# COMMAND ----------

# DBTITLE 1,Project header
print("Project: BioVanguard Therapeutics - Commercial Analytics")
print("Spark version:", spark.version)

# COMMAND ----------

# DBTITLE 1,Source path header
# MAGIC %md
# MAGIC ## 2. Source Landing Path
# MAGIC
# MAGIC Defines the bronze landing volume path used for all raw source files.

# COMMAND ----------

# DBTITLE 1,Source path
SOURCE_PATH = "/Volumes/biovanguard/bronze/landing/"

print(SOURCE_PATH)

# COMMAND ----------

# DBTITLE 1,File inventory header
# MAGIC %md
# MAGIC ## 3. Landing File Inventory
# MAGIC
# MAGIC Lists every raw source file (with sizes) available for ingestion.

# COMMAND ----------

files = dbutils.fs.ls(SOURCE_PATH)

for file in files:
    print(file.name, file.size)

# COMMAND ----------

# DBTITLE 1,Source preview header
# MAGIC %md
# MAGIC ## 4. Source File Preview
# MAGIC
# MAGIC Previews `src_product.csv` to confirm headers and values before ingestion.

# COMMAND ----------

display(
    spark.read
    .option("header", "true")
    .csv(SOURCE_PATH + "src_product.csv")
)